# 01_Recherche

Phase 1. Bis Woche 2 ein erster Prozesskandidat als Prosa, bis Woche 3 Quellen, Erkenntnisse, der überarbeitete Referenzprozess und Leitfragen für das Interview. Die Recherche läuft bis zum ersten Interview weiter.

## Was hierher gehört

| Datei | Inhalt |
|---|---|
| `quellen.md` | Eine Zeile je Quelle: Titel, Link, Datum des Abrufs, zwei Sätze Erkenntnis |
| `erkenntnisse.md` | Welche Muster wiederholen sich? Was ist gescheitert, und warum? Jede Aussage mit Verweis auf eine Quelle |
| `prozess-beschreibung.md` | Der Referenzprozess in Prosa: zwei bis zehn Sätze, Rollen, Schritte, Entscheidungen, Rückschleifen |
| `leitfragen.md` | Fünf bis acht Fragen für das Interview, nach Ablauf, Informationen, Entscheidung, Aufwand sortiert |

## Prüfen

- Jede Erkenntnis hat eine Quelle. Eine KI-Antwort ohne Quelle ist eine Vermutung.
- Die Prozessbeschreibung nennt mindestens zwei Rollen und eine Entscheidung.
- Die Leitfragen fragen nach Tätigkeiten und Informationen, nicht nach Wunsch-Automatisierungen.

Einstieg in die Quellen: Kurswebsite, Materialien, Abschnitte „Literatur“ und „Praxis und Rahmen“.
