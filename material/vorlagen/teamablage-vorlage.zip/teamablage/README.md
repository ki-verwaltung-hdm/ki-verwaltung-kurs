# Teamablage: KI in der Verwaltung, Gruppe N

Gemeinsamer Ordner der Gruppe für das HdM-Projekt „KI in der Verwaltung“ (WS 2026/27). Die Struktur folgt den fünf Phasen des Projekts. Jeder Ordner hat eine eigene README mit dem, was hineingehört.

| Ordner | Phase | Inhalt |
|---|---|---|
| `01_Recherche` | Recherche | Quellen, Erkenntnisse, Referenzprozess, Leitfragen |
| `02_Interviews` | Interviews | Leitfaden, Protokolle, offene Fragen |
| `03_Prozessmodelle` | Modellierung | Ist- und Soll-Modell als `.bpmn` und als Bild, Begründung |
| `04_Prototyp` | Prototyp | n8n-Exporte, Prompts im Wortlaut, Mock-Daten, Testfälle |
| `05_Bewertung` | Bewertung | Testbelege, Grenzen, Empfehlungen, Präsentation |

## Zum Start ausfüllen

- Gruppennummer oben im Titel eintragen.
- Namen der Gruppenmitglieder und den gemeinsamen Arbeitstermin in `TEAM.md` eintragen.
- `AGENTS.md` anpassen, sobald der Prozess feststeht. Diese Datei liest der Coding-Agent zu Beginn jedes Auftrags.

## Regeln für alles in diesem Ordner

- Keine Realdaten. Alle Beispieldaten sind erfunden und als solche gekennzeichnet.
- Keine Namen von Verwaltungsmitarbeitenden, Studierenden oder Bewerbenden. In Protokollen und Modellen stehen Rollen.
- Keine Passwörter, Schlüssel oder Zugangsdaten, auch nicht in n8n-Exporten oder Screenshots.
- Dateien, die der Coding-Agent erzeugt hat, erst nach Prüfung durch eine Person ablegen.
- Wichtige Entscheidungen mit Datum in `ENTSCHEIDUNGEN.md` festhalten.

## Vor jedem Montagstermin

1. Stand in `STAND.md` aktualisieren: fertig, offen, blockiert.
2. Eine Person stellt den Stand in zwei Minuten vor.

Kurswebsite: https://kirenz.github.io/ki-verwaltung-kurs/
